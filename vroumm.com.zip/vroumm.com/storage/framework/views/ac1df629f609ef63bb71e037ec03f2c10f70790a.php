<?php $__env->startSection('title'); ?>
vroumm-home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('morefiles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.css')); ?>"> 

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.slider-component'); ?>

<?php echo $__env->renderComponent(); ?>


<section class="roberto-about-area section-padding-100-0">
    <!-- Hotel Search Form Area -->
    <div class="hotel-search-form-area">
        <div class="container">
            <div class="hotel-search-form">
                <?php $__env->startComponent('components.ride-search-component'); ?>

                <?php echo $__env->renderComponent(); ?>


            </div>
        </div>
    </div>

    <div class="container mt-100">
        <div class="row align-items-center">
            <div class="col-12 col-lg-6">
                <!-- Section Heading -->
                <div class="section-heading wow fadeInUp" data-wow-delay="100ms">
                    <h6> <?php echo e(__('About Vroumm')); ?></h6>
                    <h3><?php echo e(__('Vroumm takes you Everywhere you go')); ?></h3>
                </div>
                <div class="about-us-content mb-100">
                    <h5 class="wow fadeInUp" data-wow-delay="300ms"><?php echo e(__('We offer various destinations across Cameroon. With over 2000 Cars connected  for a perfect journey no matter where your destination is')); ?></h5>

                </div>
            </div>

            <div class="col-12 col-lg-6">
                <div class="about-us-thumbnail mb-100 wow fadeInUp" data-wow-delay="700ms">
                    <div class="row no-gutters">
                        <div class="col-6">
                            <div class="single-thumb" >
                                <div class="text-on-img  " ><h3 class="text-white"><b>Yaounde</b></h3></div>
                                <img src=<?php echo e(asset("img/yaounde.png")); ?> alt="">
                                  
                            </div>
                            <div class="single-thumb">
                                <div class="text-on-img " ><h3 class="text-white"><b>Douala</b></h3></div>
                                <img src=<?php echo e(asset("img/douala.png")); ?> alt="">
                            </div>  
                        </div>
                        <div class="col-6">
                            <div class="single-thumb">
                                <div class="text-on-img " ><h3 class="text-white"><b>Buea</b></h3></div>
                                <img src=<?php echo e(asset("img/buea.png")); ?> alt="">
                            </div> 
                            <div class="single-thumb">
                                <div class="text-on-img " ><h3 class="text-white"><b>Maroua</b></h3></div>
                                <img src=<?php echo e(asset("img/bamenda.png")); ?> alt="">
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<div class="container mt-100">
    <div class="row align-items-center">


        <div class="col-12 col-lg-6">
            <div class="about-us-thumbnail mb-100 wow fadeInUp" data-wow-delay="700ms">
                <div class="row no-gutters">
                    <div class="col-6">
                        <div class="single-thumb" >
                            <div class="text-on-img  " ><h3 class="text-white"><b>Bamenda</b></h3></div>
                            <img src=<?php echo e(asset("img/bamenda2.png")); ?> alt="">
                               
                        </div>
                        <div class="single-thumb">
                            <div class="text-on-img " ><h3 class="text-white"><b>Garoua</b></h3></div>
                            <img src=<?php echo e(asset("img/north.png")); ?> alt="">
                        </div> 
                    </div>
                    <div class="col-6">
                        <div class="single-thumb">
                            <div class="text-on-img " ><h3 class="text-white"><b>Ebolowa</b></h3></div>
                            <img src=<?php echo e(asset("img/ebo.png")); ?> alt="">
                        </div>
                        <div class="single-thumb">
                            <div class="text-on-img " ><h3 class="text-white"><b>Bertoua</b></h3></div>
                            <img src=<?php echo e(asset("img/bert.png")); ?> alt="">
                        </div>
                    </div>

                </div>
            </div>
        </div>



        <div class="col-12 col-lg-6">
            <!-- Section Heading -->
            <div class="section-heading wow fadeInUp" data-wow-delay="100ms">
                <h6><?php echo e(__('About Vroumm')); ?></h6>
                <h3> <?php echo e(__('How to use Vroumm?')); ?></h3>
            </div>
            <div class="about-us-content mb-100">
                <h5 class="wow fadeInUp" data-wow-delay="300ms"><?php echo e(__('Very Simple just Give us your destination and we will find all drivers beside you. Then login or create your account to book for the driver that best suit you. once the driver accept your booking we notify you by email')); ?></h5>

            </div>
        </div>

    </div>
</div>




<?php $__env->startComponent('components.reasons-component'); ?>
<?php echo $__env->renderComponent(); ?>

<br>

<?php $__env->startComponent('components.ride-slider-component'); ?>
<?php echo $__env->renderComponent(); ?>



<?php $__env->startComponent('components.testimonials-component'); ?>
<?php echo $__env->renderComponent(); ?>




<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('morescript'); ?>

<script src="<?php echo e(asset('js/bootstrap-select.js')); ?>"></script>

<script type="text/javascript">

   var owl = $('.owl-carousel');
   owl.owlCarousel({
    items:3,
    loop:true,
    margin:5,
    autoplay:true,
    autoplayTimeout:2000,
    autoplayHoverPause:true
});
   $('.play').on('click',function(){
    owl.trigger('play.owl.autoplay',[1000])
})
   $('.stop').on('click',function(){
    owl.trigger('stop.owl.autoplay')
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/home.blade.php ENDPATH**/ ?>