        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <!-- Popper -->
        <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
        <!-- Bootstrap -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <!-- All Plugins -->
        <script src="<?php echo e(asset('js/roberto.bundle.js')); ?>"></script>
        <!-- Active -->
        <script src="<?php echo e(asset('js/default-assets/active.js')); ?>"></script>

         <?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/components/js-linked-component.blade.php ENDPATH**/ ?>