<?php $__env->startSection('title'); ?>
vroumm-page-not-found
<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>
<br><br><br><br><br><br><br>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h3 class="text-center text-danger"><?php echo e(__('Sorry this page does not exist')); ?></h3>
			
		</div>
		
	</div>
</div><br><br><br><br><br><br><br><br>



<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/errors/404.blade.php ENDPATH**/ ?>