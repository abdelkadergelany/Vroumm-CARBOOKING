<?php $__env->startSection('title'); ?>
vroumm-notifications
<?php $__env->stopSection(); ?>


<?php $__env->startSection('notification'); ?>
text-success
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- Page Content  -->







 <div class="container-fluid ">
  



<div class="list-group">
<?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $not): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php if($not->data['type']=='confirmation'): ?>

<?php if($not->read_at==null): ?>
<a target="_blank" href="<?php echo e(route('see_details')); ?>?rideId=<?php echo e($not->data['rideId']); ?>&bookingId=<?php echo e($not->data['bookingId']); ?>" class="list-group-item list-group-item-action font-weight-bold border-warning "><i  class="fa fa-bell " aria-hidden="true"></i>&nbsp;&nbsp; 
 <?php echo e(__('Booking confirmation')); ?> <?php echo e(__('for the ride')); ?> <span class="text-info"><?php echo e(getFrom($not->data['rideId'])); ?>-<?php echo e(getTo($not->data['rideId'])); ?>

 </span> <br><span class="text-secondary"><?php echo e(getDater($not->data['rideId'])); ?>  &nbsp;     <?php echo e(getTimer($not->data['rideId'])); ?></span></a>
 <?php endif; ?>

 <?php if($not->read_at!=null): ?>
<a target="_blank" href="<?php echo e(route('see_details')); ?>?rideId=<?php echo e($not->data['rideId']); ?>&bookingId=<?php echo e($not->data['bookingId']); ?>" class="list-group-item list-group-item-action  "><i  class="fa fa-bell " aria-hidden="true"></i>&nbsp;&nbsp; 
 <?php echo e(__('Booking confirmation')); ?> <?php echo e(__('for the ride')); ?> <span class="text-info"><?php echo e(getFrom($not->data['rideId'])); ?>-<?php echo e(getTo($not->data['rideId'])); ?>

 </span> <br><span class="text-secondary"><?php echo e(getDater($not->data['rideId'])); ?>  &nbsp;     <?php echo e(getTimer($not->data['rideId'])); ?></span></a>
 <?php endif; ?>

  <?php endif; ?>



 <?php if($not->data['type']=='request'): ?>
 <?php if($not->read_at==null): ?>
<a target="_blank" href="<?php echo e(route('bookrideconfirmationCallback')); ?>?RideId=<?php echo e($not->data['rideId']); ?>&bookingId=<?php echo e($not->data['bookingId']); ?>" class="list-group-item list-group-item-action font-weight-bold border-warning"><i  class="fa fa-bell " aria-hidden="true"></i>&nbsp;&nbsp; 
 <?php echo e(__('Booking request')); ?> <?php echo e(__('for the ride')); ?> <span class="text-info"><?php echo e(getFrom($not->data['rideId'])); ?>-<?php echo e(getTo($not->data['rideId'])); ?>

 </span> <br><span class="text-secondary"><?php echo e(getDater($not->data['rideId'])); ?>  &nbsp;     <?php echo e(getTimer($not->data['rideId'])); ?></span></a>
 <?php endif; ?>

  <?php if($not->read_at!=null): ?>
<a target="_blank" href="<?php echo e(route('bookrideconfirmationCallback')); ?>?RideId=<?php echo e($not->data['rideId']); ?>&bookingId=<?php echo e($not->data['bookingId']); ?>" class="list-group-item list-group-item-action disabled"><i  class="fa fa-bell " aria-hidden="true"></i>&nbsp;&nbsp; 
 <?php echo e(__('Booking request')); ?> <?php echo e(__('for the ride')); ?> <span class="text-info"><?php echo e(getFrom($not->data['rideId'])); ?>-<?php echo e(getTo($not->data['rideId'])); ?>

 </span> <br><span class="text-secondary"><?php echo e(getDater($not->data['rideId'])); ?>  &nbsp;     <?php echo e(getTimer($not->data['rideId'])); ?></span></a>
 <?php endif; ?>

 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<a href="#" class="list-group-item list-group-item-action font-weight-bold border-warning"><i  class="fa fa-bell " aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e(__('No notification')); ?></a>
<?php endif; ?>


 


</div>

 </div>








<nav class="roberto-pagination wow fadeInUp mb-100" data-wow-delay="1000ms">

 
</nav>








<?php $__env->stopSection(); ?>

<?php $__env->startSection('morescript'); ?>

<script type="text/javascript">
 $('.counter-count').each(function () {
  $(this).prop('Counter',0).animate({
    Counter: $(this).text()
  }, {
    duration: 5000,
    easing: 'swing',
    step: function (now) {
      $(this).text(Math.ceil(now));
    }
  });
});
</script>
<?php echo $__env->make('flashy::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/notifications.blade.php ENDPATH**/ ?>