<?php $__env->startSection('title'); ?>
vroumm-contact
<?php $__env->stopSection(); ?>

<?php $__env->startSection('morefiles'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/ride-registration.css')); ?>"> 
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.css')); ?>"> 

<?php $__env->stopSection(); ?>


<?php $__env->startSection('featured-image'); ?>
<?php $__env->startComponent('components.featured-image-component'); ?>

<?php $__env->slot('current_page'); ?>
<?php echo e(__('Offer a ride')); ?>


<?php $__env->endSlot(); ?>

<?php $__env->slot('current_page_bread_crumb'); ?>
<?php echo e(__('Offer a ride')); ?>

<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div class="container" >


  <form id="regForm" action="<?php echo e(route('bookride')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <p  class="btn btn-lg btn-info m-auto text-center"><?php echo e(__('Ride Informations')); ?></p>








    <div class="tab ">


     


      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <p><?php echo e(__('please review the form and correct the following errors')); ?>:</p>
        <ul> 
          
         
         <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p> <?php echo e(__('Given names')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Surname')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('phone number is invalid')); ?> </p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('City')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['quater'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Quater')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['idcard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Id Card Number')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         
          <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__(' Date Of Birth')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         
        
        </ul>
      </div>
      <?php endif; ?>
      <!-- <h6 class="text-center text-white text-uppercase pt-2"><b> <?php echo e(__('Itinerary')); ?><b></h6> -->



       <h6 class="text-center text-white text-uppercase pt-2"><b><?php echo e(__('Personal Infos')); ?>:<b></h6>

         <div class="form-row">
          <div class="form-group col-md-6">
            <label for="fname">
             <?php echo e(__('Surname')); ?>

           </label>
           <div class="form-holder">

           <?php if($userInfos->FisrtName!=null): ?>
           <input value="<?php echo e($userInfos->FisrtName); ?>" required type="text" id="fname"  placeholder="first name" name="fname"  class=" form-control">
             <?php else: ?>
               <input required type="text" id="fname"  placeholder="first name" name="fname"  class=" form-control">
             <?php endif; ?>
          </div>
        </div>

        <div class="col-xl">
          <label for="lname">
            <?php echo e(__('Given names')); ?>

          </label>
          <div class="form-holder">
             <?php if($userInfos->LastName!=null): ?>
            <input value="<?php echo e($userInfos->LastName); ?>" required type="text" id="lname"  placeholder="given name" name="lname"  class=" form-control">
            <?php else: ?>
             <input required type="text" id="lname"  placeholder="given name" name="lname"  class=" form-control">
             <?php endif; ?>
          </div>
        </div>




      </div>




      <div class="form-row ">
        <div class="form-group col-md-6">
          <label for="city">
           <?php echo e(__('City')); ?>

         </label>
         <div class="form-holder">


            <?php if($userInfos->city!=null): ?>
    <input required id="city" value="<?php echo e($userInfos->city); ?>" placeholder="city" name="city"  type="text" class="form-control">
    <?php else: ?>
    <input required id="city" placeholder="city" name="city"  type="text" class="form-control">
    <?php endif; ?>

        </div>
      </div>
      <div class="form-group col-md-6">
        <label for="quater">
         <?php echo e(__('Quater')); ?>

       </label>
       <div class="form-holder">

        <?php if($userInfos->quater!=null): ?> 
   <input required value="<?php echo e($userInfos->quater); ?>" id="quater" name="quater" placeholder="quater"  type="text" class="form-control " >
   <?php else: ?>
   <input required id="quater" name="quater" placeholder="quater"  type="text" class="form-control " >
   <?php endif; ?>

      </div>
    </div>
  </div>



  <div class="form-row ">
    <div class="form-group col-md-6">
      <label for="idnum">
        <?php echo e(__('Id Card Number')); ?>

      </label>
      <div class="form-holder">

        
      <?php if($userInfos->IdCard!=null): ?>
     <input required value="<?php echo e($userInfos->IdCard); ?>" id="idnum"  name="idcard" placeholder="id card number" type="text" class="form-control">
     <?php else: ?>
     <input required id="idnum"  name="idcard" placeholder="id card number" type="text" class="form-control">
     <?php endif; ?>
      </div>
    </div>
    <div class="form-group col-md-6">
      <label for="driving " style="visibility: hidden;">
        ------
      </label>
      <div class="form-holder">

        <input  id="driving" name="idlicence"  disabled type="text" class="form-control " >

      </div>
    </div>
  </div>



  <div class="form-row ">
    <div class="form-group col-md-6">
      <label for="email">
        <?php echo e(__('email')); ?>

      </label>
      <div class="form-holder">

        <input disabled value="<?php echo e(Auth::user()->email); ?>"   id="email" placeholder="email" type="email" class="form-control">
      </div>
    </div>
    <div class="form-group col-md-6">
      <label for="phone">
       <?php echo e(__('Phone')); ?>

     </label>
     <div class="form-holder">

 <?php if($userInfos->phone1!=null): ?>
    <input required value="<?php echo e($userInfos->phone1); ?>" placeholder="eg: 698261547" pattern="[0-9]{9}" id="phone" name="phone"   type="tel" class="form-control " >
    <?php else: ?>
    <input required placeholder="eg: 698261547" pattern="[0-9]{9}" id="phone" name="phone"   type="tel" class="form-control " >
    <?php endif; ?>




    </div>
  </div>
</div>



<div class="row">


 <div class="col-md-4">
  <label for="sexe">
    <?php echo e(__(' Gender')); ?>

  </label>
  <div class="form-group">
    <select required id="sexe" class="form-control" name="gender"  >
       <?php if($userInfos->sexe!=null): ?>
     <?php if($userInfos->sexe=='Male'): ?>

     <option  selected>Male</option>
     <option  >Female</option>
     <?php endif; ?>

     <?php if($userInfos->sexe=='Female'): ?>
     <option selected >Female</option>
     <option  >Male</option>
     <?php endif; ?>

     <?php endif; ?>


     <?php if($userInfos->sexe==null): ?>
     <option value="">Chose your gender</option>
     <option >Male</option>
     <option  >Female</option>
     <?php endif; ?>
    </select>

  </div>
</div>
<div class="col-md-4">
  <label for="DOB">
    <?php echo e(__(' Date Of Birth')); ?>

  </label>
  <div class="form-group">

    <?php if($userInfos->DOB!=null): ?>

   <input required value="<?php echo e($userInfos->DOB); ?>" type="text" name="dob" class=" inputer form-control datepicker-here" placeholder="yyyy-mm-dd" data-language='en' data-date-format="yyyy-mm-dd" id="DOB">
   <?php else: ?>
   <input required type="text" name="dob" class=" inputer form-control datepicker-here" placeholder="yyyy-mm-dd" data-language='en' data-date-format="yyyy-mm-dd" id="DOB">

   <?php endif; ?>



 </div>
</div>

<div class="col-md-4">
  <label for="pob">
    <?php echo e(__(' Place Of Birth')); ?>

  </label>
  <div class="form-group">

<?php if($userInfos->PlaceOfBirth!=null): ?>

   <input required value="<?php echo e($userInfos->PlaceOfBirth); ?>" type="text" name="pob" class="  form-control " placeholder="place of birth"  id="pob">
   <?php else: ?>
    <input required type="text" name="pob" class="  form-control " placeholder="place of birth"  id="pob">
<?php endif; ?>



 </div>
</div>


</div>


</div>














<input type="hidden" value="<?php echo e($rideId); ?>" name="rideId">


<input type="hidden" value="<?php echo e($passenger); ?>" name="passenger">


<div class="row">
  <!-- <div style="float:right;">
    <button class="btn-info btn-sm" type="button" id="prevBtn" onclick="nextPrev(-1)"> <?php echo e(__(' Previous')); ?></button>
    <button class="btn-info btn-sm" type="button" id="nextBtn" onclick="nextPrev(1)"> <?php echo e(__(' Next')); ?></button>
  </div> -->
  <div class="form-group col-md-4"></div>
  <div class="form-group col-md-4"><br>
    <input  type="submit"  class="form-control btn-info" name="" value="<?php echo e(__('Book Now')); ?>">

    <!--  <button class="btn btn-lg btn-info" type="submit" value="">Book Now</button> -->
  </div>
  <div class="form-group col-md-4"></div>
</div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;">
  <span class="step"></span>
  <span class="step"></span>
</div>

</form>


</div>

<br><br><br><br>








<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('morescript'); ?>


<!-- <script src="<?php echo e(asset('js/ride-registration.js')); ?>"></script> -->
<script src="<?php echo e(asset('js/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/datepicker.en.js')); ?>"></script>
<script >
  $( document ).ready(function() {
   var x = document.getElementsByClassName("tab");
   x[0].style.display = "block";
 });


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/bookingride.blade.php ENDPATH**/ ?>