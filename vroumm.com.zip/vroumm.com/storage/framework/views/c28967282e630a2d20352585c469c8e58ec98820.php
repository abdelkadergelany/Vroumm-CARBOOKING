<?php $__env->startSection('title'); ?>
vroumm-Profile
<?php $__env->stopSection(); ?>


<?php $__env->startSection('profile'); ?>
text-success
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


  <!-- Page Content  -->









               
                    <form action="<?php echo e(route('profiler')); ?>" method="POST"><?php echo csrf_field(); ?>
                        <h3><?php echo e(__('Personal Infos')); ?></h3>
                        <div class="form-row">
                            <div class="col-xl">
                                <label for="fname">
                                    <?php echo e(__('Surname')); ?>

                                </label>
                                <div class="form-holder">
                                    <?php if($userInfos->FisrtName!=null): ?>
                                    <input name="fname" id="fname" value="<?php echo e($userInfos->FisrtName); ?>"  type="text"  class=" form-control">
                                    <?php else: ?>
                                     <input name="fname" id="fname"   type="text"  class=" form-control">
                                    <?php endif; ?>

                                    
                                </div>
                                <span class="text-danger"> <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(__('Surname')); ?> incorrect <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p> </span>
                            </div>

                            <div class="col-xl">
                                <label for="lname">
                                    <?php echo e(__('Given names')); ?>

                                </label>
                                <div class="form-holder">
                                   <?php if($userInfos->LastName!=null): ?>
                                    <input name="lname" id="lname" value="<?php echo e($userInfos->LastName); ?>" type="text" class="form-control">
                                     <?php else: ?>
                                      <input name="lname" id="lname"  type="text" class="form-control">
                                       <?php endif; ?>
                                </div>
                                <span class="text-danger">  <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <?php echo e(__('Given names')); ?> incorrect <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>




                        </div><br>




                        <div class="form-row ">
                            <div class="col-xl">
                                <label for="city">
                                   <?php echo e(__('City')); ?>

                                </label>
                                <div class="form-holder">
                                   <?php if($userInfos->city!=null): ?>
                                    <input name="city" id="city" value="<?php echo e($userInfos->city); ?>"  type="text" class="form-control">
                                    <?php else: ?>
                                     <input name="city" id="city"   type="text" class="form-control">
                                    <?php endif; ?>
                                </div>
                                 <span class="text-danger">  <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(__('City')); ?> incorrect <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                            <div class="col-xl">
                                <label for="quater">
                                     <?php echo e(__('Quater')); ?>

                                </label>
                                <div class="form-holder">
                                     <?php if($userInfos->quater!=null): ?>
                                    <input name="quater" value="<?php echo e($userInfos->quater); ?>"  type="text" class="form-control " id="quater">
                                    <?php else: ?>
                                     <input name="quater"   type="text" class="form-control " id="quater">
                                    <?php endif; ?>
                                </div>
                                <span class="text-danger">   <?php $__errorArgs = ['quater'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(__('Quater')); ?> incorrect <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                        </div><br>



                        <div class="form-row ">
                            <div class="col-xl">
                                <label for="idnum">
                                     <?php echo e(__('Id Card Number')); ?>

                                </label>
                                <div class="form-holder">
                                     <?php if($userInfos->IdCard!=null): ?>
                                    <input name="idcard" id="idnum"  value="<?php echo e($userInfos->IdCard); ?>" type="text" class="form-control">
                                     <?php else: ?>
                                      <input name="idcard" id="idnum"   type="text" class="form-control">
                                     <?php endif; ?>
                                </div>

                                 <span class="text-danger">    <?php $__errorArgs = ['idcard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(__('Id Card Number')); ?> incorrect <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                            <div class="col-xl">
                                <label for="driving">
                                     <?php echo e(__('Driving Licence')); ?>

                                </label>
                                <div class="form-holder">
                                     <?php if($userInfos->DriverLicenceNumber!=null): ?>

                                    <input name="idlicence" value="<?php echo e($userInfos->DriverLicenceNumber); ?>" type="text" class="form-control "  id="driving">
                                     <?php else: ?>
                                      <input name="idlicence"  type="text" class="form-control "  id="driving">
                                      <?php endif; ?>
                                </div>
                                 <span class="text-danger">   <?php $__errorArgs = ['idlicence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(__('Driving Licence')); ?> incorrect <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                        </div><br>



                        <div class="form-row ">
                            <div class="col-xl">
                                <label for="email">
                                    <?php echo e(__('email')); ?>

                                </label>
                                <div class="form-holder">

                                    <input disabled  value="<?php echo e(Auth::user()->email); ?>" type="email" class="form-control">
                                </div>
                            </div>
                            <div class="col-xl">
                                <label for="phone">
                                    Phone
                                </label>
                                <div class="form-holder">
                                     <?php if($userInfos->phone1!=null): ?>

                                    <input name="phone" value="<?php echo e($userInfos->phone1); ?>" type="tel" class="form-control "  id="phone">
                                     <?php else: ?>
                                       <input name="phone"   type="tel" class="form-control "  id="phone">
                                      <?php endif; ?>
                                </div>
                                <span class="text-danger">   <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(__('phone number is invalid')); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                        </div><br>



                        <div class="row">

                            <div class="col-sm-4">
                                <label for="DOB">
                                    <?php echo e(__(' Date Of Birth')); ?>

                                </label>
                                <div class="form-group">

                                       <?php if($userInfos->DOB!=null): ?>
                                        
                                         <input id="DOB" type="text" value="<?php echo e($userInfos->DOB); ?>"  class=" form-control datepicker-here" data-language='en' data-date-format="dd - mm - yyyy" name="dob">
                                          <?php else: ?>
                                          <input id="DOB" type="text" name="dob" class=" form-control datepicker-here" data-language='en' data-date-format="dd - mm - yyyy">
                                           <?php endif; ?>
                                     
                               


                                 <!--  <input  value="Male" min="18" value="22" type="number" class="form-control"> -->
                             </div>
                         </div>
                         <div class="col-sm-4">
                            <label for="sex">
                                <?php echo e(__(' Gender')); ?>

                            </label>
                            <div class="form-group">
                                <select id="sex" class="form-control" name="gender" >
                                     <?php if($userInfos->sexe!=null): ?>
                                        <?php if($userInfos->sexe=='Male'): ?>

                                         <option  selected>Male</option>
                                         <option  >Female</option>
                                         <?php endif; ?>

                                          <?php if($userInfos->sexe=='Female'): ?>
                                          <option selected >Female</option>
                                          <option  >Male</option>
                                           <?php endif; ?>

                                       <?php endif; ?>


                                       <?php if($userInfos->sexe==null): ?>
                                       <option value="">Chose your gender</option>
                                    <option >Male</option>
                                    <option  >Female</option>
                                    <?php endif; ?>
                                </select>

                            </div>
                        </div>
                         <div class="col-sm-4">
                            <label for="phone2">

                                <?php echo e(__('Whatssap number')); ?>

                            </label>
                            <div class="form-group">
                                <?php if($userInfos->phoene2!=null): ?>
                                <input value="<?php echo e($userInfos->phone2); ?>" placeholder="eg: 698261547" pattern="[0-9]{9}" id="phone2" name="phone2"   type="tel" class="form-control " >
                                <?php else: ?>
                                <input  placeholder="eg: 698261547" pattern="[0-9]{9}" id="phone" name="phone2"   type="tel" class="form-control " >
                                 <?php endif; ?>

                            </div>
                             <span class="text-danger">    <?php $__errorArgs = ['phone2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e(__('whatsapp phone number is invalid')); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        </div>




                    </div><br>

                    <input type="submit" value="Modify" class="btn form-control  btn-info" id="buttonAdd"> 

                </form>









      


<?php $__env->stopSection(); ?>




<?php $__env->startSection('morescript'); ?>


<?php echo $__env->make('flashy::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/profile.blade.php ENDPATH**/ ?>