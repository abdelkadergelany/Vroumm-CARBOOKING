 <div class="partner-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="partner-logo-content d-flex align-items-center justify-content-between wow fadeInUp" data-wow-delay="300ms">
                        <!-- Single Partner Logo -->
                        <a href="#" class="partner-logo"><img src=<?php echo e(asset("img/toyota.jpg")); ?> alt=""></a>
                        <!-- Single Partner Logo -->
                        <a href="#" class="partner-logo"><img src=<?php echo e(asset("img/part1.jpg")); ?> alt=""></a>
                        <!-- Single Partner Logo -->  
                        <a href="#" class="partner-logo"><img src=<?php echo e(asset("img/part2.jpg")); ?> alt=""></a>
                        <!-- Single Partner Logo -->
                        <a href="#" class="partner-logo"><img src=<?php echo e(asset("img/nissan.png")); ?> alt=""></a>
                        <!-- Single Partner Logo -->
                        <a href="#" class="partner-logo"><img src=<?php echo e(asset("img/partenar.png")); ?> alt=""></a>
                    </div>                          
                </div>
            </div>
        </div>
    </div><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/components/partenar-component.blade.php ENDPATH**/ ?>