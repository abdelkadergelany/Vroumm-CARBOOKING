<?php $__env->startSection('title'); ?>
booking-validation
<?php $__env->stopSection(); ?>

<?php $__env->startSection('featured-image'); ?>
<?php $__env->startComponent('components.featured-image-component'); ?>

<?php $__env->slot('current_page'); ?>
<?php echo e(__('Booking request validation')); ?>


<?php $__env->endSlot(); ?>

<?php $__env->slot('current_page_bread_crumb'); ?>
<?php echo e(__('Booking request validation')); ?>

<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>




<br><br><br>
<div class=" container p-3" style="background-color: #a6a6a666 ; z-index: 1;
border-radius: 10px;
box-shadow:10px 10px grey, -1em 0 .4em grey;
transition: box-shadow 0.3s ease-in;">

<div class="row">

  <div class="col-md-4">
    <span> <?php echo e(__('Driver')); ?> </span><br>
    <figure>
      <img src="http://danblackonleadership.info/wp-content/uploads/2015/10/driving-man-760x506.jpg" class="rounded-circle" alt="Cinque Terre" width="70" height="70">
      <figcaption><?php echo e(Auth::user()->name); ?></figcaption>
      <!-- <figcaption>Sexe: Male</figcaption> -->
  </figure>
</div>
<div class="col-md-4">
    <h2 class="text-center text-primary">  <?php echo e(\Carbon\Carbon::parse($details->DepartureDate)->format('j F, Y')); ?>  &nbsp;     <?php echo e($details->DepartureTime); ?></h2>
</div>
<div class="col-md-4"><br><br>
    <h4 class="text-center text-danger"><?php echo e(__('Price')); ?>: <?php echo e($details->price); ?> FCFA</h4>
</div>

</div>

<div class="row">

  <div class="col-md-6">
     <?php echo e(__('Leaving From')); ?>: <h3><?php echo e($details->From); ?></h3>

 </div>

 <div class="col-md-6">
     <?php echo e(__('Going To')); ?>: <h3><?php echo e($details->To); ?></h3>
 </div>

</div>

<div class="row">

  <div class="col-md-6">
     <?php echo e(__('Pick Point')); ?> <h3><?php echo e($details->PickPoint); ?></h3>
 </div>

 <div class="col-md-6">
  <?php echo e(__('Drop Point')); ?>:<h3><?php echo e($details->DropPoint); ?></h3>
</div>

</div>

<hr>
<div class="row">

  <div class="col-md-6">
     <figure>
        <img src="img/caravatar.png" class="rounded-circle" alt="" width="300" height="300">
        <figcaption class="font-weight-bolder"></figcaption>
    </figure>
</div>

<div class="col-md-6">


  <span> <?php echo e(__('Passenger')); ?> </span><br>
  <figure>
      <img src="http://danblackonleadership.info/wp-content/uploads/2015/10/driving-man-760x506.jpg" class="rounded-circle" alt="Cinque Terre" width="70" height="70">
      <figcaption><?php echo e($passengerInfo->name); ?></figcaption>
      <!-- <figcaption>Sexe: Male</figcaption> -->
  </figure><br><br>

  <?php echo e(__('Number of Sites booked')); ?>:<h3><?php echo e($bookingdetail->PlaceBooked); ?></h3>

<!--   <?php echo e(__("Car's Model")); ?>:<h3><?php echo e($details->CarModel); ?></h3>
  <?php echo e(__("Car's Color")); ?>:<h3><?php echo e($details->CarColor); ?></h3>
  <?php echo e(__('Number of sites')); ?>:<h3><?php echo e($details->NumberOfPlaces); ?></h3>
  <?php echo e(__('Kg Per person')); ?>:<h3><?php echo e($details->KgPerPerson); ?> Kg</h3>
  <?php echo e(__('Passsengers')); ?>:<h3><?php echo e($details->KgPerPerson); ?> Kg</h3> -->
</div>

</div>
<hr>




<div class="row p-3" style="background-color: #999999">


 <div class="form-group col-md-6">
    <form action="<?php echo e(route('bookrideconfirmationCallback')); ?>" method="post"><?php echo csrf_field(); ?>


       <input type="hidden" name="action"   value="confirm" >
       <input type="hidden" name="bookingId"   value="<?php echo e($bookingdetail->id); ?>" >

       <input type="hidden" name="rideId"   value="<?php echo e($details->id); ?>" >

       <input type="submit" class="form-control btn btn-success " value="<?php echo e(__('Confirm')); ?>"> 
   </form>
</div>

<div class="form-group col-md-6">
    <form action="<?php echo e(route('bookrideconfirmationCallback')); ?>" method="post"><?php echo csrf_field(); ?>

      <input type="hidden" name="action"   value="cancel" >
      <input type="hidden" name="bookingId"   value="<?php echo e($bookingdetail->id); ?>" >

      <input type="hidden" name="rideId"   value="<?php echo e($details->id); ?>" >

      <input type="submit" class="form-control btn btn-danger " value="<?php echo e(__('Cancel')); ?>">
  </form>

</div>

</div>





</div>


</div>

<br><br><br>






<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/bookingrequestValidation.blade.php ENDPATH**/ ?>