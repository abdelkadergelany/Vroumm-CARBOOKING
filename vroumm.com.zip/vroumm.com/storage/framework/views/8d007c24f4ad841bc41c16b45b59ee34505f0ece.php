<?php $__env->startSection('title'); ?>
vroumm-Register
<?php $__env->stopSection(); ?>


<?php $__env->startSection('morefiles'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('featured-image'); ?>
<?php $__env->startComponent('components.featured-image-component'); ?>

<?php $__env->slot('current_page'); ?>
 <?php echo e(__('Register')); ?>


<?php $__env->endSlot(); ?>

<?php $__env->slot('current_page_bread_crumb'); ?>
 <?php echo e(__('Register')); ?>

<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
<br><br><hr>

 <div class="container">
        <div class=" cta-content bg-img bg-overlay jarallax" style="background-image: url(<?php echo e(asset("img/1.jpg")); ?>);">
          <div class="container">
            <div class="row">
              <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                <div class="card card-signin my-5">
                  <div class="card-body">

                    <form method="POST" action="<?php echo e(route('register',app()->getLocale())); ?>">
                        <?php echo csrf_field(); ?>
                    <h5 class="card-title text-center"><?php echo e(__('Create Your Account')); ?></h5>
                    <form class="form-signin">
                     <div class="form-label-group">


            



                        <input type="text" id="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Name" 
                        value="<?php echo e(old('name')); ?>" required autofocus autocomplete="name" name="name">
                        <label for="name"><?php echo e(__('Name')); ?></label>

                                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>




                    </div>

                    <div class="form-label-group">



            



                        <input type="email" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email address" required  value="<?php echo e(old('email')); ?>" autocomplete="email" autofocus name="email">
                        <label for="email"><?php echo e(__('Email address')); ?></label>

                          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-label-group">


  


                        <input type="password" id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" required autocomplete="new-password" name="password">
                        <label for="password"><?php echo e(__('Password')); ?></label>

                         <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    </div>

                    <div class="form-label-group">




                        <input type="password" id="password-confirm" class="form-control" name="password_confirmation" placeholder="Retype your Password" required autocomplete="new-password">
                        <label for="password-confirm"><?php echo e(__('Password')); ?></label>
                    </div>

                   
                    <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit"><?php echo e(__('Register')); ?></button>
                    <hr class="my-4">
                 

                    <a href="<?php echo e(url('login/google')); ?>"><button style="background-color: #ea4335;" class="btn btn-lg btn-google btn-alert btn-block text-capitalize" type="button"><i class="fa fa-google mr-2"></i> <?php echo e(__('Register with Google')); ?></button></a><br>
             <a href="<?php echo e(url('login/facebook')); ?>"><button style="background-color: #3b5998;" class="btn btn-lg btn-facebook btn-block text-capitalize" type="button"><i class="fa fa-facebook mr-2" aria-hidden="true"></i>  <?php echo e(__('Register with Facebook')); ?></button><a>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div><br><br><br><br><br><br>






<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/auth/register.blade.php ENDPATH**/ ?>