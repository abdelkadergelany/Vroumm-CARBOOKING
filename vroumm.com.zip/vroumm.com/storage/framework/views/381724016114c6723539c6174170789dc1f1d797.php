<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    
    <title> <?php echo $__env->yieldContent('title'); ?></title>

    
    <!-- All required CSS files -->
    <?php $__env->startComponent('components.css-linked-component'); ?>
    <?php echo $__env->renderComponent(); ?>
    <link rel="stylesheet" href="css/sidebarstyle.css">
    <?php echo $__env->yieldContent('morefiles'); ?>

</head>
<body>
    <?php $__env->startComponent('components.header-component'); ?>

    <?php echo $__env->renderComponent(); ?>



    <?php $__env->startComponent('components.featured-image-component'); ?>

    <?php $__env->slot('current_page'); ?>
    <?php echo e(__('Profile')); ?>


    <?php $__env->endSlot(); ?>

    <?php $__env->slot('current_page_bread_crumb'); ?>
    <?php echo e(__('Profile')); ?>

    <?php $__env->endSlot(); ?>

    <?php echo $__env->renderComponent(); ?>



    <br>
    <div class="container side" >
        <br>
        <h1 class="text-center text-capitalize"><?php echo e(__('My account')); ?></h1>
        <hr><br>

        <div class="wrapper">
            <!-- Sidebar  -->
            <nav id="sidebar">
                <div class="sidebar-header">
                   <figure>
                    <img src="thumbnail/<?php echo e(getProfilePict(Auth::user()->id)); ?>" class="rounded-circle" alt="" width="150" height="150">
                    <figcaption class="font-weight-bolder "><?php echo e(Auth::user()->name); ?></figcaption>
                </figure>
            </div>

            <ul class="list-unstyled components">

             <li class="<?php echo $__env->yieldContent('profile'); ?>">
                <a   href="<?php echo e(route('profiler'
                    )); ?>">Profile</a>
                </li>
                
                <li class="<?php echo $__env->yieldContent('photo'); ?>">
                    <a href="<?php echo e(route('photo'
                        )); ?>">Photo</a>
                    </li>
                    <li class="<?php echo $__env->yieldContent('mycar'); ?>">
                        <a href="<?php echo e(route('mycar'
                            )); ?>"> <?php echo e(__('My Car')); ?></a>
                        </li>

                        <li class="<?php echo $__env->yieldContent('offeredride'); ?>">
                            <a href="<?php echo e(route('offered-rides'
                                )); ?>"><?php echo e(__('Offered Rides')); ?></a>
                            </li>
                            <li class="<?php echo $__env->yieldContent('bookedride'); ?>">
                                <a href="<?php echo e(route('booked-rides')); ?>"><?php echo e(__('Booked Rides')); ?></a>
                            </li>
                            <li class="<?php echo $__env->yieldContent('notification'); ?>">
                                <a href="<?php echo e(route('notifications'
                                    )); ?>"><?php echo e(__('Notifications')); ?></a>
                                </li>
                            </ul>

                            <ul class="list-unstyled CTAs">
                                <li>
                                    <a href="<?php echo e(route('logout'
                                        )); ?>"  onclick="event.preventDefault();  document.getElementById('logout-form').submit();" class="download"><?php echo e(__('Logout')); ?></a>
                                    </li>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </ul>
                            </nav>

                            <!-- Page Content  -->
                            <div id="content">

                                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                                    <div class="container-fluid">

                                        <button type="button" id="sidebarCollapse" class="btn btn-info">
                                            <i class="fa fa-align-left"></i>

                                            <span>Toggle Sidebar</span>
                                        </button>
                                        <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                            <i class="fa fa-align-justify"></i>
                                        </button>

                                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                            <ul class="nav navbar-nav ml-auto">
                                                <li class="nav-item active">
                                                    <a  class=" nav-link" href="<?php echo e(route('offer-ride'
                                                        )); ?>"><?php echo e(__('Offer a ride')); ?></a>
                                                    </li>
                                                    <li class="nav-item active">
                                                        <a class="nav-link" href="<?php echo e(route('find-ride'
                                                            )); ?>"><?php echo e(__('Find a ride')); ?></a>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                        </nav>

                                        <div class="container-fluid" >



                                            <section class="m-sm-auto">




                                             <?php echo $__env->yieldContent('content'); ?>




                                         </section>
                                     </div>

                                 </div>
                             </div>



                         </div>










                         <?php $__env->startComponent('components.partenar-component'); ?>

                         <?php echo $__env->renderComponent(); ?>

                         <?php $__env->startComponent('components.footer-component'); ?>

                         <?php echo $__env->renderComponent(); ?>
                         <?php $__env->startComponent('components.js-linked-component'); ?>
                         <?php echo $__env->renderComponent(); ?>
                         <?php echo $__env->yieldContent('morescript'); ?>




                         <script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
                         <script src="<?php echo e(asset('js/datepicker.en.js')); ?>"></script>

                         <script type="text/javascript">
                            $(document).ready(function () {
                                $('#sidebarCollapse').on('click', function () {
                                    $('#sidebar').toggleClass('active');
                                });
                            });
                        </script>



                    </body>
                    </html>
<?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/layouts/dashboard-template.blade.php ENDPATH**/ ?>