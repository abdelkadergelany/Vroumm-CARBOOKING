<section class="welcome-area">
    <div class="welcome-slides owl-carousel">
     
        <div class="single-welcome-slide bg-img bg-overlay" style="background-image: url(<?php echo e(asset("img/axe-douala.png")); ?>);" data-img-url="img/axe-douala.png">                           
            <!-- Welcome Content -->
            <div class="welcome-content h-100">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <!-- Welcome Text -->
                        <div class="col-12">
                            <div class="welcome-text text-center">
                                <h6 data-animation="fadeInLeft" data-delay="250ms"><?php echo e(__('for inter urban transport in Cameroon')); ?> </h6>
                                <h2 data-animation="fadeInLeft" data-delay="500ms"><?php echo e(__('WELCOME TO VROUMM SERVICES')); ?></h2>
                                <a href="<?php echo e(route('home')); ?>" class="btn roberto-btn btn-2" data-animation="fadeInLeft" data-delay="800ms"><?php echo e(__('FIND A RIDE NOW')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Single Welcome Slide -->
        <div class="single-welcome-slide bg-img bg-overlay" style="background-image: url(<?php echo e(asset("img/yaounde.jpg")); ?>);" data-img-url="img/yaounde.jpg">
            <!-- Welcome Content -->          
            <div class="welcome-content h-100">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <!-- Welcome Text -->
                        <div class="col-12">
                            <div class="welcome-text text-center">
                                <h6 data-animation="fadeInUp" data-delay="200ms"><?php echo e(__('Tell us where you want to go')); ?></h6>
                                <h2 data-animation="fadeInUp" data-delay="550ms"><?php echo e(__('Choose your destination and the car that suits you best')); ?> </h2>
                                <a href="<?php echo e(route('about')); ?>" class="btn roberto-btn btn-2" data-animation="fadeInUp" data-delay="800ms">
                                <?php echo e(__('Discover Our Services')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="single-welcome-slide bg-img bg-overlay" style="background-image: url(<?php echo e(asset("img/driver.jpg")); ?>);" data-img-url="img/driver.jpg">
                                                 
            <div class="welcome-content h-100">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        
                        <div class="col-12">
                            <div class="welcome-text text-center">
                                <h6 data-animation="fadeInLeft" data-delay="250ms"><?php echo e(__('Do You Have a Car?')); ?> </h6>
                                <h2 data-animation="fadeInLeft" data-delay="500ms"><?php echo e(__('Register And Offer a Ride')); ?></h2>
                                <a href="<?php echo e(route('register')); ?>" class="btn roberto-btn btn-2" data-animation="fadeInLeft" data-delay="800ms"><?php echo e(__('Rgister here')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            

        </div>
    </section><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/components/slider-component.blade.php ENDPATH**/ ?>