

                        <form action="<?php echo e(route('find-ride')); ?>" method="get"><?php echo csrf_field(); ?>

                          <div class="row " style="background-color: #6c757da8">
                            <div class="col-md-4 col-lg-4">
                             <label for="first-disabled" class="p-1"><?php echo e(__('Leaving From')); ?></label>
                             <select required  id="first-disabled" class=" selectpicker form-control" data-hide-disabled="false"
                             data-live-search="true" name="From" >
                             <option value="" selected><?php echo e(__('select a city')); ?></option>

                             <?php $__currentLoopData = $city=getCities(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option ><?php echo e($cit->name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                         </select>
                     </div>

                     <div class="col-md-4 col-lg-4">
                         <label for="second-disabled-disabled" class="p-1"><?php echo e(__('Going To')); ?></label>
                         <select required  id="second-disabled" class=" selectpicker form-control" data-hide-disabled="false"
                         data-live-search="true" name="To" >
                         <option value="" selected><?php echo e(__('select a city')); ?></option>
                           <?php $__currentLoopData = $city=getCities(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option ><?php echo e($cit->name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                 </div>
                 
                 <div class="col-md-4 col-lg-4">
                    <label for="" class="p-1" style="visibility: hidden;">Check</label>
                    <button type="submit" class=" form-control btn roberto-btn btn-primary "><?php echo e(__('Check')); ?> </button>
                </div>
            </div>
        </form>
<?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/components/ride-search-component.blade.php ENDPATH**/ ?>