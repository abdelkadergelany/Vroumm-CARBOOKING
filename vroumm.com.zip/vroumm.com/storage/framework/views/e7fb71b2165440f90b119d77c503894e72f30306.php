    <div class="roberto--video--area bg-img bg-overlay jarallax section-padding-0-100" style="background-image:
     url( <?php echo e(asset("img/$pictname")); ?>);">
        <div class="container h-100">                                  
            <div class="row h-100 align-items-center justify-content-center">
                <div class="col-12 col-md-6">
                    <!-- Section Heading -->
                    <div class="section-heading text-center white wow fadeInUp" data-wow-delay="100ms">
                        <h6><?php echo e(__('Ultimate Solution For Inter Urban Transport')); ?></h6>
                        <h2>VROUMM</h2>
                    </div>
                    
                </div>
            </div>
        </div>
    </div><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/components/video-area-component.blade.php ENDPATH**/ ?>