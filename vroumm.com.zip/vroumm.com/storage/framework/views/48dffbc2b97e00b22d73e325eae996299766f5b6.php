<?php $__env->startSection('title'); ?>
vroumm-details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('featured-image'); ?>
<?php $__env->startComponent('components.featured-image-component'); ?>

<?php $__env->slot('current_page'); ?>
<?php echo e(__('Ride details')); ?>


<?php $__env->endSlot(); ?>

<?php $__env->slot('current_page_bread_crumb'); ?>
<?php echo e(__('Ride details')); ?>

<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<br><br><br>
<div class=" container p-3" style="background-color: #a6a6a666 ; z-index: 1;
border-radius: 10px;
box-shadow:10px 10px grey, -1em 0 .4em grey;
transition: box-shadow 0.3s ease-in;">

<div class="row">

  <div class="col-md-4">
    <span> <?php echo e(__('Driver')); ?> </span><br>
    <figure>
      <img src="thumbnail/<?php echo e(getProfilePict($details->userId)); ?>" class="rounded-circle" alt="Cinque Terre" width="150" height="150">
      <figcaption><?php echo e(getName($details->userId)); ?></figcaption>
      <!-- <figcaption>Sexe: Male</figcaption> -->
    </figure>
  </div>
  <div class="col-md-4">
    <h5 class="text-center text-primary">  <?php echo e(\Carbon\Carbon::parse($details->DepartureDate)->format('j F, Y')); ?>  &nbsp;     <?php echo e($details->DepartureTime); ?></h5>
  </div>
  <div class="col-md-4"><br><br>
    <h5 class="text-center text-danger"><?php echo e(__('Price')); ?>: <?php echo e($details->price); ?> FCFA</h5>
  </div>

</div>

<div class="row">

  <div class="col-md-6">
   <?php echo e(__('Leaving From')); ?>: <h3><?php echo e($details->From); ?></h3>

 </div>

 <div class="col-md-6">
   <?php echo e(__('Going To')); ?>: <h3><?php echo e($details->To); ?></h3>
 </div>

</div>

<div class="row">

  <div class="col-md-6">
   <?php echo e(__('Pick Point')); ?> <h3><?php echo e($details->PickPoint); ?></h3>
 </div>

 <div class="col-md-6">
  <?php echo e(__('Drop Point')); ?>:<h3><?php echo e($details->DropPoint); ?></h3>
</div>

</div>

<hr>
<div class="row">

  <div class="col-md-6">
   <figure>
    <img src="img/caravatar.png" class="rounded-circle" alt="" width="300" height="300">
    <figcaption class="font-weight-bolder"></figcaption>
  </figure>
</div>

<div class="col-md-6">
  <?php echo e(__("Car's Model")); ?>:<h3><?php echo e($details->CarModel); ?></h3>
  <?php echo e(__("Car's Color")); ?>:<h3><?php echo e($details->CarColor); ?></h3>
  <?php echo e(__('Number of sites')); ?>:<h3><?php echo e($details->NumberOfPlaces); ?></h3>
  <?php echo e(__('Kg Per person')); ?>:<h3><?php echo e($details->KgPerPerson); ?> Kg</h3>
  <?php echo e(__('Sites alredy booked')); ?>:<h3><?php echo e($details->passenger); ?></h3>
</div>

</div>
<hr>
<!-- <div class="row">

    <div class="form-group col-md-12">
    <span class="text-danger">Special Notice : </span><br>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia dese mollit anim id est laborum. Sed ut perspiciatis unde omnis iste. Lorem Ipsum available.
  </div> -->

   <?php if(!isset($viewtype)): ?>
  <form class="col-md-12"  action="<?php echo e(route('bookride')); ?>" method="get">

    <input type="hidden" value="<?php echo e($details->id); ?>" name="rideId">
    <?php echo csrf_field(); ?>
    <div class="row p-3" style="background-color: #999999">
     <?php if($details->NumberOfPlaces != $details->passenger ): ?>
     <label class="col-md-2">combien de place?</label>
     <div class="form-group col-md-4">

       <input placeholder="<?php echo e(__('number of places to book')); ?>" type="Number" min="1"   max="<?php echo e($details->NumberOfPlaces-$details->passenger); ?>"  class="form-control" name="passenger" required>
     </div>
     <div class="form-group col-md-4">
      <input  type="submit"  class="form-control btn-info"  value="<?php echo e(__('Book Now')); ?>">

      <!--  <button class="btn btn-lg btn-info" type="submit" value="">Book Now</button> -->
    </div>

    <?php else: ?>

    <div class="form-group col-md-12">
     <h3 class="text-center text-white"><?php echo e(__('sorry this car is full')); ?></h3>
   </div>

   <?php endif; ?>
 </form>
 <?php endif; ?>
</div>





</div>


</div>

<br><br><br>




<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/ride-details.blade.php ENDPATH**/ ?>