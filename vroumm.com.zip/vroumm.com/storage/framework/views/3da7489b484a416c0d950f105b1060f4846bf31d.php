<?php $__env->startSection('title'); ?>
offer-ride
<?php $__env->stopSection(); ?>

<?php $__env->startSection('morefiles'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/ride-registration.css')); ?>"> 
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.css')); ?>"> 

<?php $__env->stopSection(); ?>


<?php $__env->startSection('featured-image'); ?>
<?php $__env->startComponent('components.featured-image-component'); ?>

<?php $__env->slot('current_page'); ?>
<?php echo e(__('Offer a ride')); ?>


<?php $__env->endSlot(); ?>

<?php $__env->slot('current_page_bread_crumb'); ?>
<?php echo e(__('Offer a ride')); ?>

<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div class="container" >


  <form id="regForm" action="<?php echo e(route('offer-ride')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <p  class="btn btn-lg btn-info m-auto text-center"><?php echo e(__('Ride Informations')); ?></p>



    


    

    <div class="tab ">





      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <p><?php echo e(__('please review the form and correct the following errors')); ?>:</p>
        <ul> 
          <?php $__errorArgs = ['departure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p> <?php echo e(__('Departure Date is required')); ?> </p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p> <?php echo e(__('Departure time is required')); ?> </p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p> <?php echo e(__('Given names')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Surname')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['phone2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('whatsapp phone number is invalid')); ?> </p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('phone number is invalid')); ?> </p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('City')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['quater'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Quater')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['idcard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Id Card Number')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['idlicence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Driving Licence')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__(' Date Of Birth')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['picktpoint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Pick Point')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['dropoint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Drop Point')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['carmodel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__("Car's Model")); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__("Car's Color")); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['kg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Kg Per person')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Price')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['sites'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Number of sites')); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <?php $__errorArgs = ['To'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__('Going To')); ?> incorrect.&nbsp;<?php echo e(__('destination can not be same with departure city')); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          
        </ul>
      </div>
      <?php endif; ?>
      <h6 class="text-center text-white text-uppercase pt-2"><b> <?php echo e(__('Itinerary')); ?><b></h6>


        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="first-disabled"><b><?php echo e(__('Leaving From')); ?></b></label>

            <select   id="first-disabled" class="inputer selectpicker form-control " data-hide-disabled="false"
            data-live-search="true" name="From" >

            <?php $__currentLoopData = $city=getCities(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option ><?php echo e($cit->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </select>
        </div>

        <div class="form-group col-md-6 " >

         <label for="second-disabled"><b><?php echo e(__('Going To')); ?></b></label>

         <select  id="second-disabled" class="inputer selectpicker form-control" data-hide-disabled="false"
         data-live-search="true" name="To" >
         <?php $__currentLoopData = $city=getCities(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option ><?php echo e($cit->name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       </select>

     </div>
   </div>



   <div class="form-row">
    <div class="form-group col-md-6">


      <div class="form-group">
        <label for="Pick-Point"><b><?php echo e(__('Pick Point')); ?></b></label>
        <input  type="text" class="inputer form-control " id="Pick-Point" placeholder="eg: devant Total Ngousso" name="picktpoint">
      </div>
      
    </div>





    <div class="form-group col-md-6 " >


      <label for="Drop-Point"><b><?php echo e(__('Drop Point')); ?></b></label>
      <input  type="text" class=" inputer form-control" id="Drop-Point" placeholder="Drop Point" name="dropoint">
      
      
      

    </div>
  </div>





  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="Departure-Date"><?php echo e(__('Departure date')); ?></label>
      <input placeholder="yyyy-mm-dd" type="text" class=" inputer form-control datepicker-here" data-language='en' data-date-format=" yyyy-mm-dd" id="Departure-Date" name="departure"  >
      
    </div>
    <div class="form-group col-md-6">
      <label for="hour">Heure</label>
      <input placeholder="H:M:S" type="time" class=" inputer form-control "  id="hour" name="hour"  >

    </div>
  </div>


  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="Car-Model"><?php echo e(__("Car's Model")); ?></label>

      <?php if($car->model != null): ?>
      <input type="text" class=" inputer form-control " value="<?php echo e($car->model); ?>"  id="Car-Model" placeholder="eg:Toyota Land Cruiser" name="carmodel">
      <?php else: ?>
      <input type="text" class=" inputer form-control "  id="Car-Model" placeholder="eg:Toyota Land Cruiser" name="carmodel">
      <?php endif; ?>

    </div>
    <div class="form-group col-md-3">
      <label for="color"><?php echo e(__('Color')); ?></label>

      <?php if($car->color != null): ?>
      <input type="text" value="<?php echo e($car->color); ?>" class=" inputer form-control " placeholder="eg:black"  id="color" name="color">
      <?php else: ?>
      <input type="text" class=" inputer form-control " placeholder="eg:black"  id="color" name="color">
      <?php endif; ?>
    </div>
    <div class="form-group col-md-3">
      <label for="kg"><?php echo e(__('Kg Per person')); ?> </label>
      <input type="number" min="0" class=" inputer form-control " name="kg"  id="kg" placeholder="how many kg per peron ">

    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="price">
        <b> <?php echo e(__('Price')); ?></b>
      </label><input type="number" name="price" placeholder="eg: 3500" class=" inputer form-control "  id="price">

    </div>
    <div class="form-group col-md-6"> 
      <label for="place">
        <b> <?php echo e(__('Number of sites')); ?></b>
      </label><input type="number" min="1" placeholder="nombre de places disponibles" name="sites" class=" inputer form-control "  id="place">

    </div>
  </div>


</div>









<div class="tab" >

 <h6 class="text-center text-white text-uppercase pt-2"><b><?php echo e(__('Personal Infos')); ?>:<b></h6>

   <div class="form-row">
    <div class="form-group col-md-6">
      <label for="fname">
       <?php echo e(__('Surname')); ?>

     </label>
     <div class="form-holder">
       <?php if($userInfos->FisrtName!=null): ?>
       <input value="<?php echo e($userInfos->FisrtName); ?>" type="text" id="fname" placeholder="fisrt name"  name="fname"   class="inputer form-control">
       <?php else: ?>
       <input type="text" id="fname" placeholder="fisrt name"  name="fname"   class="inputer form-control">
       <?php endif; ?>
     </div>
   </div>

   <div class="col-xl">
    <label for="lname">
      <?php echo e(__('Given names')); ?>

    </label>
    <div class="form-holder">
     <?php if($userInfos->LastName!=null): ?>
     <input value="<?php echo e($userInfos->LastName); ?>" type="text" id="lname"  placeholder="given name" name="lname"  class="inputer form-control">
     <?php else: ?>
     <input  type="text" id="lname"  placeholder="given name" name="lname"  class="inputer form-control">

     <?php endif; ?>
   </div>
 </div>




</div>




<div class="form-row ">
  <div class="form-group col-md-6">
    <label for="city">
     <?php echo e(__('City')); ?>

   </label>
   <div class="form-holder">
    <?php if($userInfos->city!=null): ?>
    <input id="city" value="<?php echo e($userInfos->city); ?>" placeholder="city" name="city"  type="text" class="form-control">
    <?php else: ?>
    <input id="city" placeholder="city" name="city"  type="text" class="form-control">
    <?php endif; ?>
    
  </div>
</div>
<div class="form-group col-md-6">
  <label for="quater">
   <?php echo e(__('Quater')); ?>

 </label>
 <div class="form-holder">
   <?php if($userInfos->quater!=null): ?> 
   <input value="<?php echo e($userInfos->quater); ?>" id="quater" name="quater" placeholder="quater"  type="text" class="form-control " >
   <?php else: ?>
   <input id="quater" name="quater" placeholder="quater"  type="text" class="form-control " >
   <?php endif; ?>

 </div>
</div>
</div>



<div class="form-row ">
  <div class="form-group col-md-6">
    <label for="idnum">
      <?php echo e(__('Id Card Number')); ?>

    </label>
    <div class="form-holder">
     <?php if($userInfos->IdCard!=null): ?>
     <input value="<?php echo e($userInfos->IdCard); ?>" id="idnum"  name="idcard" placeholder="id card number" type="text" class="form-control">
     <?php else: ?>
     <input id="idnum"  name="idcard" placeholder="id card number" type="text" class="form-control">
     <?php endif; ?>
   </div>
 </div>
 <div class="form-group col-md-6">
  <label for="driving">
    <?php echo e(__('Driving Licence')); ?>

  </label>
  <div class="form-holder">
    <?php if($userInfos->DriverLicenceNumber!=null): ?>
    <input value="<?php echo e($userInfos->DriverLicenceNumber); ?>" id="driving" name="idlicence" placeholder="driving licence number" type="text" class="form-control " >
    <?php else: ?>
    <input id="driving" name="idlicence" placeholder="driving licence number" type="text" class="form-control " >
    <?php endif; ?>

  </div>
</div>
</div>



<div class="form-row ">
  <div class="form-group col-md-6">
    <label for="email">
      <?php echo e(__('email')); ?>

    </label>
    <div class="form-holder">

      <input disabled id="email" value="<?php echo e(Auth::user()->email); ?>" type="email" class="form-control">
    </div>
  </div>
  <div class="form-group col-md-6">
    <label for="phone">
     <?php echo e(__('Phone')); ?>

   </label>
   <div class="form-holder">
    <?php if($userInfos->phone1!=null): ?>
    <input value="<?php echo e($userInfos->phone1); ?>" placeholder="eg: 698261547" pattern="[0-9]{9}" id="phone" name="phone"   type="tel" class="form-control " >
    <?php else: ?>
    <input placeholder="eg: 698261547" pattern="[0-9]{9}" id="phone" name="phone"   type="tel" class="form-control " >
    <?php endif; ?>
  </div>
</div>
</div>



<div class="row">

 <div class="col-md-4">
  <label for="phone">
   <?php echo e(__('Whatssap number')); ?>

 </label>
 <div class="form-group">
  <?php if($userInfos->phoene2!=null): ?>
  <input value="<?php echo e($userInfos->phone2); ?>" placeholder="eg: 698261547" pattern="[0-9]{9}" id="phone" name="phone2"   type="tel" class="form-control " >
  <?php else: ?>
  <input placeholder="eg: 698261547" pattern="[0-9]{9}" id="phone" name="phone2"   type="tel" class="form-control " >
  <?php endif; ?>
</div>
</div>
<div class="col-md-4">
  <label for="sexe">
    <?php echo e(__(' Gender')); ?>

  </label>
  <div class="form-group">
    <select id="sexe" class="form-control" name="gender"  >
     <?php if($userInfos->sexe!=null): ?>
     <?php if($userInfos->sexe=='Male'): ?>

     <option  selected>Male</option>
     <option  >Female</option>
     <?php endif; ?>

     <?php if($userInfos->sexe=='Female'): ?>
     <option selected >Female</option>
     <option  >Male</option>
     <?php endif; ?>

     <?php endif; ?>


     <?php if($userInfos->sexe==null): ?>
     <option value="">Chose your gender</option>
     <option >Male</option>
     <option  >Female</option>
     <?php endif; ?>
   </select>

 </div>
</div>
<div class="col-md-4">
  <label for="DOB">
    <?php echo e(__(' Date Of Birth')); ?>

  </label>
  <div class="form-group">

   <?php if($userInfos->DOB!=null): ?>

   <input value="<?php echo e($userInfos->DOB); ?>" type="text" name="dob" class=" inputer form-control datepicker-here" placeholder="yyyy-mm-dd" data-language='en' data-date-format="yyyy-mm-dd" id="DOB">
   <?php else: ?>
   <input type="text" name="dob" class=" inputer form-control datepicker-here" placeholder="yyyy-mm-dd" data-language='en' data-date-format="yyyy-mm-dd" id="DOB">

   <?php endif; ?>
   


 </div>
</div>


</div>



</div>












<div style="overflow:auto;">
  <div style="float:right;">
    <button class="btn-info btn-sm" type="button" id="prevBtn" onclick="nextPrev(-1)"> <?php echo e(__(' Previous')); ?></button>
    <button class="btn-info btn-sm" type="button" id="nextBtn" onclick="nextPrev(1)"> <?php echo e(__(' Next')); ?></button>
  </div>
</div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;">
  <span class="step"></span>
  <span class="step"></span>
</div>

</form>


</div>

<br><br><br><br>








<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('morescript'); ?>


<script src="<?php echo e(asset('js/ride-registration.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/datepicker.en.js')); ?>"></script>
<script >
  $('#Departure-Date').datepicker({
    language: 'en',
    minDate: new Date() // Now can select only dates, which goes after today
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/offer-ride.blade.php ENDPATH**/ ?>