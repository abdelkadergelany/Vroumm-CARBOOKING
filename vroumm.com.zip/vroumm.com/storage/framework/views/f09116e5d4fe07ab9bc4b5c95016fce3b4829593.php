<?php $__env->startSection('title'); ?>
vroumm-picture
<?php $__env->stopSection(); ?>


 <?php $__env->startSection('morefiles'); ?> 

     <link rel="stylesheet" href="<?php echo e(asset('css/uploadpict.css')); ?>"> 
     
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('photo'); ?>
text-success
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


  <!-- Page Content  -->
   
               
                     <h3 class="text-capitalize"><?php echo e(__('Change your profile picture')); ?></h3>
                     <?php if($errors->any()): ?>
                      <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p> <?php echo e(__('Image Not accepted.please change the picture and try again')); ?> </p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     <?php endif; ?>
                    <div class="form-row">
                        <div class="col-xl">


                         <div class="container">
                            <div class="col-md-12">

                                <form method="POST" action="<?php echo e(route('photo')); ?>" enctype="multipart/form-data" ><?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="imgInp" > <?php echo e(__('Upload Image')); ?></label>
                                    <div class="input-group">
                                        <span class="input-group-btn">
                                            <span class="btn btn-success btn-file">
                                                <?php echo e(__('Browse')); ?>… <input required type="file" name="image" accept="image/png, image/jpeg, image/gif" id="imgInp">
                                            </span>
                                        </span>
                                        <input id='urlname'type="text" class="form-control" readonly>
                                    </div>
                                    <button id="clear" class="btn btn-danger">Clear</button>
                                    <img id='img-upload'/>
                                </div>
                                <div class="input-group">
                                   <input type="submit"  value="<?php echo e(__('Upload')); ?>" class="btn-info form-control"> 
                                </div>
                               
                                </form>
                            </div>
                        </div>


                    </div>



         

                </div><br>






<?php $__env->startSection('morescript'); ?>


<script src="<?php echo e(asset('js/uploadpict.js')); ?>"></script>
<?php echo $__env->make('flashy::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>



      


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/upload-pict.blade.php ENDPATH**/ ?>