<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    
    <title> <?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->yieldContent('morefiles'); ?>
    <!-- All required CSS files -->
    <?php $__env->startComponent('components.css-linked-component'); ?>
    <?php echo $__env->renderComponent(); ?>

</head>
<body>
  <div class="breadcrumb-area bg-img bg-overlay jarallax" style="background-image: url(http://trojanhunt.com/img/artwork/compass-needle-pointing-the-word-security-concept.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content text-center">
                        <h2 class="page-title">Vroum</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a></li>
                                
                                <li class="breadcrumb-item active" aria-current="page"></li>
                                <!-- <li class="breadcrumb-item active" aria-current="page">About Us</li> -->
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

     

    <?php echo $__env->yieldContent('featured-image'); ?>



    <?php echo $__env->yieldContent('content'); ?>


  <div class="roberto--video--area bg-img bg-overlay jarallax section-padding-0-100" style="background-image: url(https://api.cobalt.com/social/1.0/image/caravatar.png}});">
        <div class="container h-100">
            <div class="row h-100 align-items-center justify-content-center">
                <div class="col-12 col-md-6">
                    <!-- Section Heading -->
                    <div class="section-heading text-center white wow fadeInUp" data-wow-delay="100ms">
                        <h6><?php echo e(__('Ultimate Solution For Inter Urban Transport')); ?></h6>
                        <h2>VROUMM</h2>
                    </div>
                    
                </div>
            </div>
        </div>
    </div><br><br><br>
    




  

    <?php $__env->startComponent('components.footer-component'); ?>

    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.js-linked-component'); ?>
    <?php echo $__env->renderComponent(); ?>
</body>
</html>
<?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/layouts/security.blade.php ENDPATH**/ ?>