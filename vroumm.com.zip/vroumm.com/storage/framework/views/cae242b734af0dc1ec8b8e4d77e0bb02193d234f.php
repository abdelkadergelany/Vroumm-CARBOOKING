<br> <br> <br>
    <section class="roberto-cta-area">
        <div class="container">
            <div class="cta-content bg-img bg-overlay jarallax" style="background-image: url(<?php echo e(asset("img/1.jpg")); ?>);">
                <div class="row align-items-center">          
                    <div class="col-12 col-md-7">
                        <div class="cta-text mb-50">
                            <h2> <?php echo e(__('Contact us now!')); ?></h2>
                            <h6>Contact +237 6 614 48 46 <?php echo e(__('for Help')); ?> </h6>
                        </div>
                    </div>
                    <div class="col-12 col-md-5 text-right">
                        <a href="#" class="btn roberto-btn mb-50"><?php echo e(__('Contact us now!')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/components/paralax-form-component.blade.php ENDPATH**/ ?>