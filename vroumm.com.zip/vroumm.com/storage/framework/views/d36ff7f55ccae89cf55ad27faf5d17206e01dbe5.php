<?php $__env->startSection('title'); ?>
vroumm-myCar
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mycar'); ?>
text-success
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<!-- Page Content  -->

<?php if($errors->any()): ?>
<div class="alert alert-danger">
  <p><?php echo e(__('please review the form and correct the following errors')); ?>:</p>
  <ul> 
    <?php $__errorArgs = ['carmodel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__("Car's Model")); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__("Car's Color")); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['immat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e(__("Immatriculation")); ?> incorrect</p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


  </ul>
</div>
<?php endif; ?>

<h3 class=" text-capitalize"><?php echo e(__('My Car')); ?></h3>
<div class="form-row">
  <div class="col-xl">


   <div class="container-fluid">
    <div class=" col-md-12">

      <div class=" single-room-area  d-flex align-items-center mb-50 wow fadeInUp p-3" data-wow-delay="500ms" style="border-bottom: solid;" >

       <div class="container  ">



        <div class="row">
          <div class="col-xs-6">
            <figure>
              <img src="img/caravatar.png" class="rounded-circle" alt="" width="300" height="300">
              <figcaption class="font-weight-bolder"></figcaption>
            </figure>
          </div>
          <div class="col-xs-6  m-auto" >
            <span class="text-gray-dark"><?php echo e(__("Car's Model")); ?> :</span>
            <h4 class="text-capitalize">

             <?php if($car->model!=null): ?>
             <?php echo e($car->model); ?>

             <?php endif; ?>

           </h4>
           <span class="text-gray-dark">Immatriculation :</span><h4 class="text-capitalize">


             <?php if($car->immatriculation!=null): ?>
             <?php echo e($car->immatriculation); ?>

             <?php endif; ?>

           </h4>
           <span class="text-gray-dark"><?php echo e(__('Color')); ?> :</span><h4 class="text-capitalize">


             <?php if($car->color!=null): ?>
             <?php echo e($car->color); ?>

             <?php endif; ?>

           </h4>
         </div>


       </div>



       <div class="row">
         <a href="#" class=" view-detail-btn"><button class="btn btn-sm btn-info"
          data-title="add" data-toggle="modal" data-target="#add" id="buttonAdd"><?php echo e(__('Modify')); ?></button>  </a>
        </div>

      </div>
    </div>


  </div>
</div>
</div>










<div class="modal fade" id="add" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
 <div class="modal-dialog">
  <div class="modal-content">
    <form action="<?php echo e(route('mycar')); ?>" method="POST" ><?php echo csrf_field(); ?>

     <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
      <h4 class="modal-title custom_align text-capitalize" id="Heading"><?php echo e(__("Modify Your Car's information")); ?></h4>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label for="carmodel" id="editForm"><?php echo e(__("Car's Model")); ?>: </label>


        <?php if($car->model!=null): ?>
        <input class="form-control" type="text" value="<?php echo e($car->model); ?>" id="carmodel" name="carmodel" required >
        <?php else: ?>
        <input class="form-control" type="text"  id="carmodel" name="carmodel" required >
        <?php endif; ?>


      </div>
      <div class="form-group">
        <label for="immat" id="editForm">Immatriculation: </label>
        <?php if($car->immatriculation!=null): ?>
        <input class="form-control" value="<?php echo e($car->immatriculation); ?>" type="text"  id="immat" name="immat" required >
        <?php else: ?>
        <input class="form-control"  type="text"  id="immat" name="immat" required >
        <?php endif; ?>
      </div>
      <div class="form-group">

        <label for="color" id="editForm"><?php echo e(__("Car's Color")); ?>: </label>
        <?php if($car->color!=null): ?>
        <input class="form-control" value="<?php echo e($car->color); ?>" type="text"  id="color" name="color" required >
        <?php else: ?>
        <input class="form-control" type="text"  id="color" name="color" required >
        <?php endif; ?>
      </div>

    </div>
    <div class="modal-footer ">
      <input type="submit" class="btn btn-info
      btn-lg form-control" value="Update"><span class="glyphicon glyphicon-ok-sign" ></span> 
    </div>
  </form>
</div>
<!-- /.modal-content --> 
</div>
<!-- /.modal-dialog --> 
</div>





</div><br>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('morescript'); ?>


<?php echo $__env->make('flashy::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/mycars.blade.php ENDPATH**/ ?>