<?php $__env->startSection('title'); ?>
Reservation-details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('featured-image'); ?>
<?php $__env->startComponent('components.featured-image-component'); ?>

<?php $__env->slot('current_page'); ?>
<?php echo e(__("Reservation's details")); ?>


<?php $__env->endSlot(); ?>

<?php $__env->slot('current_page_bread_crumb'); ?>
<?php echo e(__("Reservation's details")); ?>

<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<br><br><br><br><br><br><br><br><hr>
<div class="container">

<table class="table table-striped table-dark">
  <thead>
    <tr>
     <th colspan="2">Details</th>
    </tr>
  </thead>
  <tbody>
   <tr >
        <td >
            <?php echo e(__('From')); ?>

        </td>
            <td>
             <?php echo e($ride->From); ?> 
        </td>
    </tr>
    <tr >
        <td>
            <?php echo e(__('To')); ?>

        </td>
            <td>
             <?php echo e($ride->To); ?> 
        </td>
    </tr>
    <tr >
        <td>
            <?php echo e(__('Pick Point')); ?>

        </td>
            <td>
            <?php echo e($ride->PickPoint); ?> 
        </td>
    </tr>

    <tr >
        <td>
            <?php echo e(__('Drop Point')); ?>

        </td>
            <td>
            <?php echo e($ride->DropPoint); ?> 
        </td>
    </tr>
    <tr >
        <td>
            Date
        </td>
            <td>
              <?php echo e(\Carbon\Carbon::parse($ride->DepartureDate)->format('j F, Y')); ?>

        </td>
    </tr>
    <tr >
        <td>
            <?php echo e(__('Time')); ?>

        </td>
            <td>
              <?php echo e($ride->DepartureTime); ?>

        </td>
    </tr>
    <tr >
        <td>
            <?php echo e(__('Driver')); ?>

        </td>
            <td>
             <?php echo e(getName($ride->userId)); ?>

        </td>
    </tr>
        <tr >
        <td>
            <?php echo e(__('Phone')); ?>

        </td>
            <td>
            <?php echo e($personalInfo->phone1); ?>

        </td>
    </tr>

   <?php if($personalInfo->phone2!=null): ?>
    <tr >
        <td>
            Whatsapp
        </td>
            <td>
             <?php echo e($personalInfo->phone2); ?>

        </td>
    </tr>
    <?php endif; ?>



    <tr >
        <td rowspan="2" >
            <?php echo e(__('Car')); ?>

        </td>
            <td>
          <table>
            <tr>
                <td><?php echo e(__('Model')); ?>:  <?php echo e($ride->CarModel); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('Color')); ?>: <?php echo e($ride->CarColor); ?></td>
            </tr>
            <tr >
        <td >
            <?php echo e(__('Price')); ?> : <b><?php echo e($ride->price); ?> FCFA</b>
        </td>
        
    </tr>
            </table>
        </td>
    </tr>
  </tbody>
</table>

</div>
<br><br><br><br><br><br><br><br><hr>

<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/seeConfirmationDetails.blade.php ENDPATH**/ ?>