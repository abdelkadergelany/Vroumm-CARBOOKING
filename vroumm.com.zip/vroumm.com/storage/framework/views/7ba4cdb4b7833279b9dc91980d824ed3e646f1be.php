<?php $__env->startSection('title'); ?>
find-rides
<?php $__env->stopSection(); ?>

<?php $__env->startSection('morefiles'); ?>


<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.css')); ?>"> 

<?php $__env->stopSection(); ?>


<?php $__env->startSection('featured-image'); ?>
<?php $__env->startComponent('components.featured-image-component'); ?>

<?php $__env->slot('current_page'); ?>
<?php echo e(__('Find a ride')); ?>


<?php $__env->endSlot(); ?>

<?php $__env->slot('current_page_bread_crumb'); ?>
<?php echo e(__('Find a ride')); ?>

<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div class="roberto-rooms-area section-padding-100-0">
  <div class="container">
    <div class="row">
      <div class="col-12 col-lg-8">
        <!-- Single Room Area -->








        <?php $__empty_1 = true; $__currentLoopData = $rides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ride): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div class="single-room-area booking-container d-flex align-items-center mb-50 wow fadeInUp p-3" data-wow-delay="500ms" >

         <div class="container  ">


           <div class="row ">
             <div  class="col-xs-12">
               <span> <?php echo e(__('Driver')); ?>  </span><br>
               <figure>
                <img src="thumbnail/<?php echo e(getProfilePict($ride->userId)); ?>" class="rounded-circle" alt="Cinque Terre" width="70" height="70">
                <figcaption class="text-capitalize"> <?php echo e(getName($ride->userId)); ?></figcaption>
              </figure>
            </div>
          </div>
          <div class="row">
            <div class="col-xs-4">
              <h6 ><span style="color: #afb4bf;"><?php echo e(__('Departure')); ?>:</span><br> <span>
               <?php echo e(\Carbon\Carbon::parse($ride->DepartureDate)->format('j F, Y')); ?>  &nbsp;     <?php echo e($ride->DepartureTime); ?></span></h6>
             </div>
             <div class="col-xs-4  m-auto" ></div>
             <div class="col-xs-4" >
              <h6><span style="color: #afb4bf;"></span><br> <span> </span></h6>
            </div>

          </div>
          <div class="row">
            <div class="col-xs-4">
              <h6 ><b> <?php echo e($ride->From); ?></b> </h6>
            </div>
            <div class="col-xs-4 m-auto" >
              <sup><i class="fa fa-long-arrow-right fa-3x" aria-hidden="true"></i></sup>
            </div>
            <div class="col-xs-4">
              <h6><b> <?php echo e($ride->To); ?></b></h6>
            </div>

          </div>

          <div class="row">
            <div class="col-xs-4">
              <h6 ><span style="color: #afb4bf;"><?php echo e(__('Pick Point')); ?>:</span><br> <span><?php echo e($ride->PickPoint); ?> </span></h6>
            </div>
            <div class="col-xs-4 m-auto" ></div>
            <div class="col-xs-4">
              <h6><span style="color: #afb4bf;"><?php echo e(__('Drop Point')); ?>:</span><br> <span><?php echo e($ride->DropPoint); ?> </span></h6>
            </div>


          </div>
          <div class="row">
           <a href="<?php echo e(route('ride-details')); ?>?id=<?php echo e($ride->id); ?>&v=123321654" class=" view-detail-btn"><button class="btn btn-sm btn-info"><?php echo e(__('View Details')); ?></button>  </a>
         </div>


       </div>
     </div>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
       <div class="single-room-area booking-container d-flex align-items-center mb-50 wow fadeInUp p-3" data-wow-delay="500ms" >

         <div class="container  ">


           <div class="row ">
             <div  class="col-xs-12">

               <h5 class="text-danger">oops!!! <?php echo e(__('No ride available for now')); ?>

                     
               </h5><p><?php echo e(__('Use filter for more rides')); ?></p>
             </div>
           </div>
           </div>
         </div>

    

     <?php endif; ?>




     <!-- Pagination -->
     <nav class="roberto-pagination wow fadeInUp mb-100" data-wow-delay="1000ms">
      <ul class="pagination">
       <?php echo e($rides->links()); ?>

     </ul>
   </nav>
 </div>

 <div class="col-12 col-lg-4">
  <!-- Hotel Reservation Area -->
  <div class="hotel-reservation--area mb-100">
    <form action="<?php echo e(route('find-ride')); ?>" method="post" class="p-3" style="background-color:lightgrey;
    z-index: 1;
    border-radius: 10px;
    box-shadow:10px 10px grey, -1em 0 .4em grey;"><?php echo csrf_field(); ?>
    <div class="form-group mb-30">
      <label for="Departure-Date"> <?php echo e(__('Filter by Date')); ?></label>

      <div class="row no-gutters">
        <div class="col-12">
          <input placeholder="yyyy-mm-dd" type="text" class=" inputer form-control datepicker-here" data-language='en' data-date-format="yyyy-mm-dd" id="Departure-Date" name="departureDate">
        </div>

      </div>

    </div>
    <div class="form-group mb-30">
      <label for="guests"><?php echo e(__('Filter by cities')); ?></label>
      <div class="row">
        <div class="form-group col-6">
          <label for="first-disabled"><?php echo e(__('From')); ?></label>
          <select required  id="first-disabled" class="inputer selectpicker form-control" data-hide-disabled="false"
          data-live-search="true" name="From" >
          
          <option selected  ><?php echo e($From?? ''); ?></option>
         
          <?php $__currentLoopData = $city=getCities(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($cit->name); ?>" ><?php echo e($cit->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
      </div>
      <div class="form-group col-6">
       <label for="second-disabled"><?php echo e(__('To')); ?></label>
       <select required id="second-disabled" class="inputer selectpicker form-control" data-hide-disabled="false"
       data-live-search="true" name="To" >
      
       <option selected><?php echo e($To?? ''); ?></option>

       <?php $__currentLoopData = $city=getCities(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <option value="<?php echo e($cit->name); ?>"  ><?php echo e($cit->name); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </select>
   </div>
 </div>
</div>

<div class="form-group">
  <button type="submit" class="btn roberto-btn w-100"><?php echo e(__('Apply Filter')); ?></button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>







<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('morescript'); ?>



<script src="<?php echo e(asset('js/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/datepicker.en.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/find-ride.blade.php ENDPATH**/ ?>