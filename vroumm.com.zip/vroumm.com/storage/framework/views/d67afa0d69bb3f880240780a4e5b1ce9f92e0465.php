<section class="roberto-testimonials-area section-padding-100-0">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-md-6">

                <div class="testimonial-thumbnail owl-carousel mb-70">


                            

                      <?php $__currentLoopData = $testimonial=getTestimonial(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
                     <img src=<?php echo e(asset("storage/testimonial_photos/$testim->photo_name")); ?> alt="Testimonial picture">
                 
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>

            <div class="col-12 col-md-6">
                <!-- Section Heading -->
                <div class="section-heading">
                    <h6><?php echo e(__('Testimonials')); ?></h6>
                    <!-- <h2>Our Customers</h2> -->
                </div>
                <!-- Testimonial Slide -->
                <div class="testimonial-slides owl-carousel mb-100">

         
                       <?php $__currentLoopData = $testimonial=getTestimonial(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!-- Single Testimonial Slide -->
                    <div class="single-testimonial-slide">
                        <h5>“<?php echo e($testim->testimonial_message); ?>”</h5>
                        <div class="rating-title">
                            <div class="rating">
                                <i class="icon_star"></i>
                                <i class="icon_star"></i>
                                <i class="icon_star"></i>
                                <i class="icon_star"></i>
                                <i class="icon_star"></i>
                            </div>
                            <h6><?php echo e($testim->name); ?> <span><?php echo e($testim->profession); ?></span></h6>
                        </div>
                    </div>


                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


              
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/components/testimonials-component.blade.php ENDPATH**/ ?>