<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>fff</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <!-- <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"> -->

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>

    <div class="container">
        <div class="row">

         <div class="col-sm-12">
            <figure>
              <img src="https://vroumm.000webhostapp.com/img/bg-img/biglog1.png" alt="Trulli" 
              style="width:20%">
              <figcaption><h3 class="text-center badge badge-success">Vroum: Online Car Booking In Cameroon</h3></figcaption>
          </figure>
         </div>
      </div>

      <div class="text-center row">
        <div class="col-sm-12"><h1><?php echo e($data['title']); ?></h1></div>
        <div class="col-sm-12"><?php echo e($data['message']); ?></div>
            
        </div>
          
      </div>
  </div>

</body>
</html>
<?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/layouts/mailTemplate.blade.php ENDPATH**/ ?>