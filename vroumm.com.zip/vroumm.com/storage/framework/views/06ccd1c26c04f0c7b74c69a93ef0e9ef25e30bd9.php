<?php $__env->startSection('title'); ?>
vroumm-About
<?php $__env->stopSection(); ?>

<?php $__env->startSection('featured-image'); ?>
<?php $__env->startComponent('components.featured-image-component'); ?>

<?php $__env->slot('current_page'); ?>
<?php echo e(__('About Us')); ?>


<?php $__env->endSlot(); ?>

<?php $__env->slot('current_page_bread_crumb'); ?>
<?php echo e(__('About Us')); ?>

<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<section class="roberto-about-us-area section-padding-100-0">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="about-thumbnail pr-lg-5 mb-50 wow fadeInUp" data-wow-delay="100ms">
                    <img src=<?php echo e(asset("img/biglog1.png")); ?> alt="">
                </div>
            </div>
            <div class="col-md-6">
                <!-- Section Heading -->
                <div class="section-heading wow fadeInUp" data-wow-delay="300ms">
                    <h6 class="text-center"><?php echo e(__('Who are we?')); ?></h6>
                    <!--  <h2>20 Years Of Experienc</h2> -->
                </div>
                <div class="about-content mb-50 wow fadeInUp" data-wow-delay="500ms">
                    <p class="text-center"><?php echo e(__('VROUMM puts you in touch with more than 2000 private drivers, for more than 6000 destinations available everywhere in Cameroon')); ?></hp>

                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row align-items-center">

            <div class="col-md-6">
                <!-- Section Heading -->
                <div class="section-heading wow fadeInUp" data-wow-delay="300ms">
                    <h6 class="text-center"><?php echo e(__('What are we doing?')); ?></h6>
                    <!--  <h2>20 Years Of Experienc</h2> -->
                </div>
                <div class="about-content mb-50 wow fadeInUp" data-wow-delay="500ms">
                    <p class="text-center"><?php echo e(__('Vroumm takes you Everywhere you go')); ?> </p>
                    <p class="text-center"><?php echo e(__('We offer various destinations across Cameroon. With over 2000 Cars connected  for a perfect journey no matter where your destination is')); ?></p>

                </div>
            </div>

            <div class="col-md-6">
                <div class="about-thumbnail pr-lg-5 mb-50 wow fadeInUp" data-wow-delay="100ms">
                    <img src=<?php echo e(asset("img/cmr.png")); ?> alt="">   
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="about-thumbnail pr-lg-5 mb-50 wow fadeInUp" data-wow-delay="100ms">
                    <img src=<?php echo e(asset("img/biglog1.png")); ?> alt="">
                </div> 
            </div>
            <div class="col-md-6">
                <!-- Section Heading -->
                <div class="section-heading wow fadeInUp" data-wow-delay="300ms">
                    <h6 class="text-center"><?php echo e(__('How it works?')); ?></h6>
                    <!--  <h2>20 Years Of Experienc</h2> -->
                </div>
                <div class="about-content mb-50 wow fadeInUp" data-wow-delay="500ms">
                    <p class="text-center"><?php echo e(__('Very Simple just Give us your destination and we will find all drivers beside you. Then login or create your account to book for the driver that best suit you. once the driver accept your booking we notify you by email')); ?></p>

                </div>
            </div>
        </div>
    </div>



    <div class="container">
        <div class="row align-items-center">

            <div class="col-md-6">
                <!-- Section Heading -->
                <div class="section-heading wow fadeInUp" data-wow-delay="300ms">
                    <h6 class="text-center"><?php echo e(__('Are you a driver or do you have your personal car?')); ?></h6>
                    <!--  <h2>20 Years Of Experienc</h2> -->
                </div>
                <div class=" about-content mb-100 wow fadeInUp" data-wow-delay="500ms">

                    <p class="text-center"><?php echo e(__('Register in less than 2 minutes and propose a ride. we will notify you by email once a passenger book for your ride')); ?></p>

                </div>
            </div>

            <div class="col-md-6">
                <div class="about-thumbnail pr-lg-5 mb-100 wow fadeInUp" data-wow-delay="100ms">
                    <img src=<?php echo e(asset("img/caravatar.png")); ?> alt="">
                </div>    
            </div>
        </div>
    </div>
</section>






<?php $__env->startComponent('components.video-area-component'); ?>
<?php $__env->slot('pictname'); ?>
paralax.jpg
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('components.paralax-form-component'); ?>

<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\VROUMM.COM\vroumm\vroumm.com\resources\views/front-pages/about.blade.php ENDPATH**/ ?>