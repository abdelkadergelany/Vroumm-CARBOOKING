<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class bookride extends Controller
{
    //
      /**
     * Create a new controller instance.
     *
     * @return void
     */
    //   public function __construct()
    //   {
    //   	$this->middleware(['auth']);
    //   }




    //   public function bookride(Request $request)
    //   {  
    //   	if($request->isMethod('get')){

    //   		return view('front-pages.bookingride')->with("passenger",$request->input('passenger'));

    //   	}


    //   	if($request->isMethod('post')){

    //   		 $validatedData = $request->validate([
         
    //     'lname' => ['required', 'alpha', 'max:50'],
    //     'city' => ['required', 'alpha', 'max:50'],
    //     'quater' => ['required', 'alpha_num', 'max:100'],
    //     'idcard' => ['required', 'regex:/[0-9]{10}/', 'max:100'], 
    //     'phone' => ['required', 'starts_with:6', 'max:9'],       
    //     'dob' =>['required'],
    //       'fname' =>['required', 'alpha', 'max:50'],
    //       'pob' => ['required', 'alpha_num', 'max:50'],
                       
    // ]);
    //           dd($validatedData);



    //   	}


    //   }






  }
