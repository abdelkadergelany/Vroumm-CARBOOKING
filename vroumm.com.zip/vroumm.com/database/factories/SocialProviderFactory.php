<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SocialProvider;
use Faker\Generator as Faker;

$factory->define(SocialProvider::class, function (Faker $faker) {
    return [
        //
    ];
});
