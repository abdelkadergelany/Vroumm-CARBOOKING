<?php

return [
    'switchPath' => 'lang',
    'store' => 'session',
    'key' => 'language',
    'redirect' => 'route', //can be set to route | back | locale
    'redirect_route' => '/',
];
