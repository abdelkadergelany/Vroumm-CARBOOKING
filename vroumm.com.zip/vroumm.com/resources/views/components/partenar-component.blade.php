 <div class="partner-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="partner-logo-content d-flex align-items-center justify-content-between wow fadeInUp" data-wow-delay="300ms">
                        <!-- Single Partner Logo -->
                        <a href="#" class="partner-logo"><img src={{asset("img/toyota.jpg")}} alt=""></a>
                        <!-- Single Partner Logo -->
                        <a href="#" class="partner-logo"><img src={{asset("img/part1.jpg")}} alt=""></a>
                        <!-- Single Partner Logo -->  
                        <a href="#" class="partner-logo"><img src={{asset("img/part2.jpg")}} alt=""></a>
                        <!-- Single Partner Logo -->
                        <a href="#" class="partner-logo"><img src={{asset("img/nissan.png")}} alt=""></a>
                        <!-- Single Partner Logo -->
                        <a href="#" class="partner-logo"><img src={{asset("img/partenar.png")}} alt=""></a>
                    </div>                          
                </div>
            </div>
        </div>
    </div>